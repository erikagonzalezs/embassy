package co.edu.javeriana.citasembajada.persistencia;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import co.edu.javeriana.citasembajada.modelo.SistemaCitasEmbajada;

public class ManejoArchivos {

	private BufferedReader buf;
	private ObjectOutputStream out;
	private ObjectInputStream inn;
	
	/**
	 * @param nompais nombre del pais de la embajada
	 * @param archtxt nombre del archivo 
	 * @return informacion de la embajada
	 * metodo que busca en un archivo la embajada solicitdada
	 */
	public String[] arch(String nompais, File file) {
	
		
		try
		{
		FileReader archivo =new FileReader(file);
		buf = new BufferedReader (archivo);
		String linea = buf.readLine();

		while (!linea.equalsIgnoreCase("#FIN"))
			{
				linea = buf.readLine();
				if(!linea.contains("#"))
					{
						String [] sistema = linea.split("\\*");
						if(sistema[1].trim().equalsIgnoreCase(nompais)) {
							sistema[3] = sistema[3].replace("%", "");
							return sistema;
						}
					}
			
			}	
		}
	
	
	catch (Exception e)
	{
		return null;
	}	
		return null;
	}
	
	/**
	 * @param archtxt nombre archivo
	 * @return lista de vectores string con los solicitantes y su informacion
	 * metodo que lee un archivo y obtiene a todos los solicitantes y su informacion
	 */
	public List <String []> usuarios(File file) {
		
		try
		{
		FileReader archivo =new FileReader(file);
		buf = new BufferedReader (archivo);
		String linea = buf.readLine();
		List<String []> usuarios = new  ArrayList<String []> ();
		
		while (!linea.equalsIgnoreCase("#FIN"))
			{
				linea = buf.readLine();
				if(!linea.contains("#"))
					{
						String [] sistema = linea.split("\\*");
						sistema[4] = sistema[4].replace(" ", "");
						usuarios.add(sistema);
					}
			
			}
		return usuarios;
		}
	
	
	catch (Exception e)
	{
		System.out.println("No se pudo cargar el archivo"+e);
	}	
		
		return null;
	}
	
	/**
	 * @param archtxt nombre archivo
	 * @return lista de vectores string 
	 * metodo que lee un aarchivo y obtiene los tipos de visa y sus requisitos
	 */
	public List <String []> visa(String archtxt) {
	
		
		try
		{
		InputStreamReader archivo = new InputStreamReader(new FileInputStream(archtxt + ".txt"));
		buf = new BufferedReader (archivo);
		String linea = buf.readLine();
		List<String []> visa = new  ArrayList<String []> ();
		
		while (!linea.equalsIgnoreCase("#FIN"))
			{
				linea = buf.readLine();
				if(linea.contains("#tipo"))
					{
					linea = buf.readLine();
						String [] sistema = linea.split("\\*");
						sistema[0] = sistema[0].replace(" ", "");
						visa.add(sistema);
					}
				if(linea.contains("#REQUISITOS"))
					{
					linea = buf.readLine();
					String lineaR = new String("");
					while(!linea.contains("#VISA") && !linea.contains("#FIN")) {
						if (!linea.contains("#VISA") && !linea.contains("#FIN")) {
							lineaR = new String(lineaR + linea + "-");
							}
						linea = buf.readLine();
						}
					lineaR = lineaR.substring(0, lineaR.length()-1);
					String [] sistema = lineaR.split("-") ;
					visa.add(sistema);
					}
			
			}
		return visa;
		}
	
	catch (Exception e)
	{
		System.out.println("No se pudo cargar el archivo"+e);
	}	
		
		return null;
	}
	
	/**
	 * @param archtxt string del archivo con los datos de visa
	 * @return lista de vectores string
	 * metodo que lee un archivo y devulve una lista con los datos
	 */
	public List <String []> cod(File file) {
		
		try
		{
		FileReader archivo =new FileReader(file);
		buf = new BufferedReader (archivo);
		String linea = buf.readLine();
		List<String []> visa = new  ArrayList<String []> ();
		
		while (!linea.equalsIgnoreCase("#FIN"))
			{
				linea = buf.readLine();
				if(!linea.contains("#id") && !linea.equalsIgnoreCase("#FIN"))
					{
						String [] sistema = linea.split("\\*");
						visa.add(sistema);
					}			
			}
		return visa;
		}
	
	catch (Exception e)
	{
		System.out.println("No existe el archivo tarifas"+e);
	}	
		
		return null;
	}
	
	/**
	 * @param archtxt nombre archivo
	 * @return pasaportes
	 * metodo que obtiene los pasaportes de los usuarios que viajan con el solicitante principal
	 */
	public String [] otrosSolicitantes(String archtxt) {
		try
		{
		InputStreamReader archivo = new InputStreamReader(new FileInputStream(archtxt + ".txt"));
		buf = new BufferedReader (archivo);
		String linea = buf.readLine();
		String [] solicitantes = null;

		while (!linea.equalsIgnoreCase("#FIN"))
			{
				linea = buf.readLine();
				if(!linea.contains("#num"))
					{
						String lineaR = new String("");
						while(!linea.contains("#FIN")) {
							if (!linea.contains("#FIN")) {
								lineaR = new String(lineaR + linea + "-");
								}
							linea = buf.readLine();
							}
						lineaR = lineaR.substring(0, lineaR.length()-1);
						solicitantes = lineaR.split("-") ;
					}
						
					
			
			}
			return solicitantes;
		}
	
	
	catch (Exception e)
	{
		System.out.println("No se pudo cargar el archivo"+e);
	}	
		
		return null;
	}

	/**
	 * @param fread fecha cita de las solicitudes
	 * @param resultado string con todos los solicitantes con cita
	 * @param embajada nombre embajada
	 * @throws IOException excepcion I/O
	 * metodo que genera un archivo con todos los solicitantes que tienen cita para la fecha
	 */
	public void reportarCitasFecha(String fread, String resultado, String embajada) throws IOException {
	
		File CTM= new File ("Citas-"+fread+".txt");
		 try {
             BufferedWriter bw;
             bw = new BufferedWriter(new FileWriter(CTM));
             bw.write("--REPORTE DE SOLICITUDES EMBAJADA DE " + embajada.toUpperCase()+ "\r\n"
					   + "Fecha: " + fread + "\r\n"
					   + "#numPass�-----nombre-----------tipoVisa----numSolicitud \r\n"
					   + resultado);
             bw.close();
         } catch (IOException ex) {
             ex.printStackTrace();
         }
	}
	
	/**
	 * @param lista lista con los beneficiarios sin descuento
	 * metodo que genera un archivo con los beneficiados sin descuento
	 */
	public void reportarListaBeneficiados(ArrayList <String> lista) {
		
		File CTM= new File ("beneficiarios.txt");
		 try {
            BufferedWriter bw;
            bw = new BufferedWriter(new FileWriter(CTM));
            for(String l : lista) {
	            bw.write(l);
            }
            bw.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
	}
	
	/**
	 * @param control sistema de embajada
	 * @param ruta ruta donde se va a guardar
	 * @throws FileNotFoundException
	 * @throws IOException
	 * metodo que serializa la embajada
	 */
	public void guardarEmbajada(SistemaCitasEmbajada control, String ruta) throws FileNotFoundException,IOException 
	{
		FileOutputStream fos = new FileOutputStream(ruta);
		out = new ObjectOutputStream(fos);
		out.writeObject(control);
	}
	
	/**
	 * @return objeto tipo banco
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * metodo que deserializa la embajada
	 */
	public SistemaCitasEmbajada cargarBanco(File file) throws FileNotFoundException,IOException, ClassNotFoundException 
	{
		SistemaCitasEmbajada control=new SistemaCitasEmbajada();
		FileInputStream fis = new FileInputStream(file);
		inn = new ObjectInputStream(fis);
		control = (SistemaCitasEmbajada)inn.readObject();
		return control;
	}
	
}
