package co.edu.javeriana.citasembajada.presentacion;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.sun.glass.events.KeyEvent;

import co.edu.javeriana.citasembajada.modelo.ControladorCitasEmbajada;

import javax.swing.JTabbedPane;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JScrollBar;
import javax.swing.ListSelectionModel;

public class InterfazGrafica extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private ControladorCitasEmbajada control = new ControladorCitasEmbajada();
	private File paisEmbajada = null;
	private File fileSolicitantes = null;
	private File tarifas = null;
	private JTable table;
	
	private DefaultTableModel def = new DefaultTableModel();
	private DefaultTableModel dtmP = new DefaultTableModel();
	private DefaultTableModel dtmS = new DefaultTableModel();
	private DefaultTableModel dtmC = new DefaultTableModel();
	private DefaultTableModel dtmL = new DefaultTableModel();
	private JTextField diasEstadia;
	private JTextField codSol;
	private JTable table2;
	private JTextField empresa;
	private JTextField cargo;
	private JTextField codSolT;
	private JTable table3;
	private JTextField numero;
	private JTable principal;
	private JTable secundario;
	private JTextField fecha;
	private JTable citasT;
	private JTable listaB;
	private JTextField txtTotal;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {					
					InterfazGrafica frame = new InterfazGrafica();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InterfazGrafica() {
		
		def.addColumn("Pass");
		def.addColumn("Nombre");
		def.addColumn("Pais");
		def.addColumn("Ciudad");
		def.addColumn("Fecha de Nacimiento");
		def.addColumn("eMail");
		def.addColumn("Informacion");
		
		dtmP.addColumn("Pass");
		dtmP.addColumn("Nombre");
		dtmP.addColumn("Pais");
		dtmP.addColumn("Ciudad");
		dtmP.addColumn("Fecha de Nacimiento");
		dtmP.addColumn("eMail");
		
		dtmS.addColumn("Pass");
		dtmS.addColumn("Nombre");
		dtmS.addColumn("Fecha de Nacimiento");
		dtmS.addColumn("Valor visa");
		dtmS.addColumn("Impuesto");
		dtmS.addColumn("Valor Toral");
		
		dtmC.addColumn("Pass");
		dtmC.addColumn("Nombre");
		dtmC.addColumn("Tipo de Visa");
		dtmC.addColumn("Numero de Solicitud");
		
		dtmL.addColumn("Pass");
		dtmL.addColumn("Nombre");
		dtmL.addColumn("Valor Total");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1198, 684);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
	
		final JTabbedPane tarjetero = new JTabbedPane(JTabbedPane.TOP);
		tarjetero.setForeground(new Color(248, 248, 255));
		tarjetero.setBackground(new Color(0, 0, 0));
		tarjetero.setBounds(0, 0, 1184, 679);
		contentPane.add(tarjetero);
		
		JPanel menu = new JPanel();
		menu.setForeground(new Color(255, 255, 255));
		menu.setBorder(new EmptyBorder(0, 0, 0, 0));
		menu.setBackground(new Color(51, 51, 51));
		
		tarjetero.addTab("Menu de Servicios", null, menu, null);
		menu.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 0));
		panel.setBounds(0, 0, 265, 621);
		menu.add(panel);
		panel.setLayout(null);
		
		JButton btnEmbajada = new JButton("Asociar Embajada del Pais");
		btnEmbajada.setHorizontalAlignment(SwingConstants.LEFT);
		btnEmbajada.setIcon(new ImageIcon("./images/menu.png"));
		btnEmbajada.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tarjetero.setSelectedIndex(1);
			}
		});
		btnEmbajada.setBounds(10, 80, 250, 55);
		btnEmbajada.setForeground(new Color(0, 0, 0));
		btnEmbajada.setBackground(new Color(51, 51, 51));
		panel.add(btnEmbajada);
		
		JButton btnSolicitantes = new JButton("Ingresar Solicitantes");
		btnSolicitantes.setHorizontalAlignment(SwingConstants.LEFT);
		btnSolicitantes.setIcon(new ImageIcon("./images/persona.png"));
		btnSolicitantes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tarjetero.setSelectedIndex(2);
			}
		});
		btnSolicitantes.setForeground(new Color(0, 0, 0));
		btnSolicitantes.setBackground(new Color(102, 102, 102));
		btnSolicitantes.setBounds(10, 138, 250, 55);
		panel.add(btnSolicitantes);
		
		JButton btnTurismo = new JButton("Solicitar Visa de Turismo");
		btnTurismo.setHorizontalAlignment(SwingConstants.LEFT);
		btnTurismo.setIcon(new ImageIcon("./images/visa.png"));
		btnTurismo.setForeground(new Color(0, 0, 0));
		btnTurismo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tarjetero.setSelectedIndex(3);
			}
		});
		btnTurismo.setBackground(new Color(51, 51, 51));
		btnTurismo.setBounds(10, 196, 250, 55);
		panel.add(btnTurismo);
		
		JButton btnTrabajo = new JButton("Solicitar Visa de Trabajo");
		btnTrabajo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tarjetero.setSelectedIndex(4);
			}
		});
		btnTrabajo.setHorizontalAlignment(SwingConstants.LEFT);
		btnTrabajo.setIcon(new ImageIcon("./images/visa.png"));
		btnTrabajo.setForeground(new Color(0, 0, 0));
		btnTrabajo.setBackground(new Color(102, 102, 102));
		btnTrabajo.setBounds(10, 254, 250, 55);
		panel.add(btnTrabajo);
		
		JButton btnCitas = new JButton("Reportar Citas");
		btnCitas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tarjetero.setSelectedIndex(5);
			}
		});
		btnCitas.setHorizontalAlignment(SwingConstants.LEFT);
		btnCitas.setIcon(new ImageIcon("./images/reporte.png"));
		btnCitas.setForeground(new Color(0, 0, 0));
		btnCitas.setBackground(new Color(51, 51, 51));
		btnCitas.setBounds(10, 312, 250, 55);
		panel.add(btnCitas);
		
		JButton btnValor = new JButton("Calcular Valor de la Visa");
		btnValor.setHorizontalAlignment(SwingConstants.LEFT);
		btnValor.setIcon(new ImageIcon("./images/dinero.png"));
		btnValor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tarjetero.setSelectedIndex(6);
			}
		});
		btnValor.setForeground(new Color(0, 0, 0));
		btnValor.setBackground(new Color(102, 102, 102));
		btnValor.setBounds(10, 370, 250, 55);
		panel.add(btnValor);
		
		JButton btnLista = new JButton("Lista de Beneficiarios");
		btnLista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tarjetero.setSelectedIndex(7);
			}
		});
		btnLista.setHorizontalAlignment(SwingConstants.LEFT);
		btnLista.setIcon(new ImageIcon("./images/lista.png"));
		btnLista.setForeground(new Color(0, 0, 0));
		btnLista.setBackground(new Color(51, 51, 51));
		btnLista.setBounds(10, 428, 250, 55);
		panel.add(btnLista);
		
		JButton btnCargar = new JButton("Cargar los Datos del Sistema");
		btnCargar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser filesEmergente = new JFileChooser();
				int returnVal = filesEmergente.showOpenDialog(null);
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					   File file = filesEmergente.getSelectedFile();
					   try {
						control.cargarEmbajada(file);
					} catch (ClassNotFoundException | IOException e1) {
						JOptionPane.showMessageDialog(null,"El archivo que ha seleccionado es incompatible","Error archivo",JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		btnCargar.setForeground(new Color(0, 0, 0));
		btnCargar.setIcon(new ImageIcon("./images/cargar.png"));
		btnCargar.setBackground(new Color(102, 102, 102));
		btnCargar.setHorizontalAlignment(SwingConstants.LEFT);
		btnCargar.setBounds(10, 486, 250, 55);
		panel.add(btnCargar);
		
		JButton btnSalvar = new JButton("Salvar los Datos del Sistema");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				javax.swing.JFileChooser jF1= new javax.swing.JFileChooser();
				String ruta = "";
				try{
					if(jF1.showSaveDialog(null)==JFileChooser.APPROVE_OPTION){
					ruta = jF1.getSelectedFile().getAbsolutePath();
					control.guardarEmbajada(ruta);
					}
				}catch (Exception ex){
					ex.printStackTrace();
				} 
			}
		});
		btnSalvar.setForeground(new Color(0, 0, 0));
		btnSalvar.setIcon(new ImageIcon("./images/salvar.png"));
		btnSalvar.setBackground(new Color(51, 51, 51));
		btnSalvar.setHorizontalAlignment(SwingConstants.LEFT);
		btnSalvar.setBounds(10, 544, 250, 55);
		panel.add(btnSalvar);
		
		JLabel img = new JLabel("");
		img.setBounds(10, 0, 240, 81);
		panel.add(img);
		img.setForeground(new Color(255, 255, 255));
		img.setIcon(new ImageIcon("./images/embajada.png"));
		
		final JLabel bandera = new JLabel("");
		bandera.setForeground(new Color(255, 255, 255));
		bandera.setHorizontalAlignment(SwingConstants.CENTER);
		bandera.setBounds(530, 11, 360, 180);
		menu.add(bandera);
		
		final JLabel pais = new JLabel("");
		pais.setHorizontalAlignment(SwingConstants.CENTER);
		pais.setForeground(new Color(255, 255, 255));
		pais.setFont(new Font("Tahoma", Font.BOLD, 85));
		pais.setBounds(455, 225, 518, 100);
		menu.add(pais);
		
		final JLabel extranjero = new JLabel("");
		extranjero.setForeground(new Color(255, 255, 255));
		extranjero.setFont(new Font("Tahoma", Font.BOLD, 80));
		extranjero.setBounds(455, 368, 110, 75);
		menu.add(extranjero);
		
		final JLabel local = new JLabel("");
		local.setForeground(new Color(255, 255, 255));
		local.setHorizontalAlignment(SwingConstants.RIGHT);
		local.setFont(new Font("Tahoma", Font.BOLD, 80));
		local.setBounds(882, 368, 265, 75);
		menu.add(local);
		
		final JLabel monedaE = new JLabel("");
		monedaE.setForeground(new Color(255, 255, 255));
		monedaE.setHorizontalAlignment(SwingConstants.CENTER);
		monedaE.setFont(new Font("Tahoma", Font.BOLD, 60));
		monedaE.setBounds(260, 464, 530, 81);
		menu.add(monedaE);
		
		final JLabel monedaL = new JLabel("");
		monedaL.setForeground(new Color(255, 255, 255));
		monedaL.setHorizontalAlignment(SwingConstants.CENTER);
		monedaL.setFont(new Font("Tahoma", Font.BOLD, 60));
		monedaL.setBounds(939, 472, 195, 64);
		menu.add(monedaL);
		
		final JLabel flecha = new JLabel(""); 
		flecha.setForeground(new Color(255, 255, 255));
		flecha.setHorizontalAlignment(SwingConstants.CENTER);
		flecha.setFont(new Font("Tahoma", Font.BOLD, 99));
		flecha.setBounds(656, 379, 124, 64);
		menu.add(flecha);
		
		final JPanel barra = new JPanel();
		barra.setForeground(new Color(255, 255, 255));
		barra.setBackground(new Color(51, 51, 51));
		barra.setBounds(260, 355, 909, 108);
		menu.add(barra);
		
		JPanel embajada = new JPanel();
		embajada.setForeground(new Color(255, 255, 255));
		embajada.setBackground(new Color(51, 51, 51));
		tarjetero.addTab("Asociar Embajada del Pais", null, embajada, null);
		embajada.setLayout(null);
		
		JLabel lblPais = new JLabel("Pais:");
		lblPais.setForeground(new Color(255, 255, 255));
		lblPais.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblPais.setBounds(110, 49, 50, 25);
		embajada.add(lblPais);
		
		final JComboBox<Object> paises = new JComboBox<Object>();
		paises.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(paisEmbajada!=null && !paises.getSelectedItem().toString().equalsIgnoreCase("")) {
					String r = control.asignarEmbajada(paises.getSelectedItem().toString(), paisEmbajada);
						String [] resultado = r.split("-");
						bandera.setIcon(new ImageIcon("./images/"+resultado[1].toLowerCase().replaceAll(" ", "")+".png"));
						pais.setText(resultado[1]);
						extranjero.setText("$1");
						local.setText("$"+resultado[2]);
						monedaE.setText(resultado[3]);
						monedaL.setText("Peso");
						flecha.setText("\u2192");
						barra.setBackground(new Color(0, 0, 0));
						JOptionPane.showMessageDialog(null,"Se ha cargado la embaja","",JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		paises.setModel(new DefaultComboBoxModel<Object>(new String[] {"", "USA", "Francia", "Chile", "Japon", "Australia"}));
		paises.setBounds(170, 48, 277, 26);
		embajada.add(paises);
		
		final JFileChooser files = new JFileChooser();
		files.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!paises.getSelectedItem().toString().equalsIgnoreCase("")) {
					paisEmbajada = files.getSelectedFile();
					String r = control.asignarEmbajada(paises.getSelectedItem().toString(), paisEmbajada);
					if(r != null) {
						String [] resultado = r.split("-");
						bandera.setIcon(new ImageIcon("./images/"+resultado[1].toLowerCase().replaceAll(" ", "")+".png"));
						pais.setText(resultado[1]);
						extranjero.setText("$1");
						local.setText("$"+resultado[2]);
						monedaE.setText(resultado[3]);
						monedaL.setText("Peso");
						flecha.setText("\u2192");
						barra.setBackground(new Color(0, 0, 0));
						JOptionPane.showMessageDialog(null,"Se ha cargado la embaja","",JOptionPane.INFORMATION_MESSAGE);
						
					}
					else {
						JOptionPane.showMessageDialog(null,"El archivo que ha seleccionado es incompatible","Error archivo",JOptionPane.ERROR_MESSAGE);
					}
			}
				else {
				    JOptionPane.showMessageDialog(null,"No ha seleccionado un pais en el menu desplegable de paises","Seleccione un pais",JOptionPane.ERROR_MESSAGE);
				}
				
				
			}
		});
		files.setControlButtonsAreShown(false);
		files.setBounds(100, 100, 1000, 500);
		embajada.add(files);
		
		JPanel solicitantes = new JPanel();
		solicitantes.setForeground(new Color(255, 255, 255));
		solicitantes.setBackground(new Color(51, 51, 51));
		tarjetero.addTab("Ingresar Solicitantes", null, solicitantes, null);
		solicitantes.setLayout(null);
		
		table = new JTable();
		table.setForeground(new Color(0, 0, 0));
		table.setBackground(Color.GRAY);
		table.setEnabled(false);
		table.setModel(def);
		table.setBounds(10, 45, 1159, 561);
		solicitantes.add(table);
		
		JButton btnSelSol = new JButton("Seleccionar Archivos de Usuarios");
		btnSelSol.setForeground(Color.BLACK);
		btnSelSol.setBackground(Color.GRAY);
		btnSelSol.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser filesEmergente = new JFileChooser();
				int returnVal = filesEmergente.showOpenDialog(null);
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					   fileSolicitantes = filesEmergente.getSelectedFile();
						String resultado = control.asignarSolicitantes(fileSolicitantes);
						if(resultado == null) {
							JOptionPane.showMessageDialog(null,"El archivo que ha seleccionado es incompatible","Error archivo",JOptionPane.ERROR_MESSAGE);
						}
						else {
							JOptionPane.showMessageDialog(null,resultado,"Operacion exitosa",JOptionPane.INFORMATION_MESSAGE);
							ArrayList<String []> usuarios = control.keys();
							while(def.getRowCount()>0) {
								def.removeRow(0);
							}
							
							for(int i=0;i<usuarios.size();i++) {
								String [] usuario = usuarios.get(i);
								Object [] row = {usuario[0],usuario[1],usuario[2],usuario[3],usuario[4],usuario[5],usuario[6]};
								def.addRow(row);
							}
						}
					} 
			}
		});
		btnSelSol.setBounds(10, 11, 1159, 23);
		solicitantes.add(btnSelSol);
		
		JScrollBar scrollBar = new JScrollBar();
		scrollBar.setBounds(1152, 45, 17, 561);
		solicitantes.add(scrollBar);
		
		JPanel turismo = new JPanel();
		turismo.setForeground(new Color(255, 255, 255));
		turismo.setBackground(new Color(51, 51, 51));
		tarjetero.addTab("Solicitar Visa de Turismo", null, turismo, null);
		turismo.setLayout(null);
		
		JLabel lblDias = new JLabel("Dias de Estadia");
		lblDias.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblDias.setForeground(Color.WHITE);
		lblDias.setBounds(454, 27, 153, 17);
		turismo.add(lblDias);
		
		diasEstadia = new JTextField("");
		diasEstadia.addKeyListener(new KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent e) {
				char c = e.getKeyChar();
				if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACKSPACE) || (c == KeyEvent.VK_DELETE))) {
					getToolkit().beep();
					e.consume();
				}
			}
		});
		diasEstadia.setBounds(617, 29, 107, 20);
		turismo.add(diasEstadia);
		diasEstadia.setColumns(10);
		
		JButton btnTarifas = new JButton("Seleccionar Tarifas para Visa y crear Solicitud Principal");
		btnTarifas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser filesEmergente = null;
				int returnVal = JFileChooser.APPROVE_OPTION;
				if(tarifas == null) {
					filesEmergente = new JFileChooser();
					returnVal = filesEmergente.showOpenDialog(null);
				}
				if (returnVal == JFileChooser.APPROVE_OPTION) {
						if(tarifas == null) {
							tarifas = filesEmergente.getSelectedFile();
							String resultado = control.asignarVisas(tarifas);
							if(resultado == null) {
								tarifas = null;
								JOptionPane.showMessageDialog(null,"Archivo incompatible","Error",JOptionPane.ERROR_MESSAGE);
							}
							else { JOptionPane.showMessageDialog(null,resultado,"",JOptionPane.INFORMATION_MESSAGE);
								}
							
						}
					    if(!(table2.getSelectedRows().length==0) && !(def.getRowCount()==0) && !(diasEstadia.getText().equals("")) && tarifas!=null) {

								int [] sRows = table2.getSelectedRows();
								String [] pass = new String [sRows.length];
								for(int i=0;i<sRows.length;i++) {
									pass [i] = (table2.getValueAt(sRows[i], 0)).toString();
								}
								String resultado = control.turismo(Integer.parseInt(diasEstadia.getText()), pass, pass[0]);
								if(resultado.contains("codigo")) {
									JOptionPane.showMessageDialog(null,"Completado exitosamente","",JOptionPane.INFORMATION_MESSAGE);
									codSol.setText(resultado.substring(6, resultado.length()));
								}
								else
									JOptionPane.showMessageDialog(null,resultado,"",JOptionPane.ERROR_MESSAGE);
					    }
					    else {
					    	if(table2.getSelectedRows().length==0)
					    		JOptionPane.showMessageDialog(null,"No ha seleccionado usuarios solicitantes de visa","Error",JOptionPane.ERROR_MESSAGE);
					    	if(def.getRowCount()==0)
					    		JOptionPane.showMessageDialog(null,"No ha cargado usuarios","Error",JOptionPane.ERROR_MESSAGE);
					    	if(diasEstadia.getText().equals("")) 
					    		JOptionPane.showMessageDialog(null,"No ha especificado los dias de estadia","Error",JOptionPane.ERROR_MESSAGE);
					    }
					} 
			}
		});
		btnTarifas.setBackground(Color.GRAY);
		btnTarifas.setBounds(155, 57, 868, 23);
		turismo.add(btnTarifas);
		
		JLabel lblCodigoDeSolicitud = new JLabel("Codigo de Solicitud");
		lblCodigoDeSolicitud.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblCodigoDeSolicitud.setForeground(Color.WHITE);
		lblCodigoDeSolicitud.setBounds(433, 91, 200, 23);
		turismo.add(lblCodigoDeSolicitud);
		
		codSol = new JTextField("");
		codSol.addKeyListener(new KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent e) {
				char c = e.getKeyChar();
				if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACKSPACE) || (c == KeyEvent.VK_DELETE))) {
					getToolkit().beep();
					e.consume();
				}
			}
		});
		codSol.setBounds(637, 91, 107, 23);
		turismo.add(codSol);
		codSol.setColumns(10);
		
		table2 = new JTable();
		table2.setModel(def);
		table2.setDefaultEditor(Object.class, null);
		table2.setBackground(Color.GRAY);
		table2.setBounds(10, 138, 1159, 427);
		turismo.add(table2);
		
		JButton btnAdicionar = new JButton("Adicionar usuario");
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			    if(!(codSol.getText().equalsIgnoreCase("")) && !(table2.getSelectedRows().length==0) && !(def.getRowCount()==0) && !(diasEstadia.getText().equals("")) && tarifas!=null) {

						int [] sRows = table2.getSelectedRows();
						String [] pass = new String [sRows.length];
						for(int i=0;i<sRows.length;i++) {
							pass [i] = (table2.getValueAt(sRows[i], 0)).toString();
						}
						String resultado = control.addTurismo(Integer.parseInt(codSol.getText()), pass);
						if(resultado.equalsIgnoreCase(""))
							JOptionPane.showMessageDialog(null,"Completado exitosamente","",JOptionPane.INFORMATION_MESSAGE);
						else	
							JOptionPane.showMessageDialog(null,resultado,"",JOptionPane.INFORMATION_MESSAGE);
			    }
			    else {
			    	if(tarifas == null)
			    		JOptionPane.showMessageDialog(null,"No han cargado las tarifas","Error",JOptionPane.ERROR_MESSAGE);
			    	if(codSol.getText().equalsIgnoreCase(""))
						JOptionPane.showMessageDialog(null,"No ha especifiado el codigo de solicitud","Error",JOptionPane.ERROR_MESSAGE);
					if(table2.getSelectedRows().length==0)
			    		JOptionPane.showMessageDialog(null,"No ha seleccionado usuarios solicitantes de visa","Error",JOptionPane.ERROR_MESSAGE);
			    	if(def.getRowCount()==0)
			    		JOptionPane.showMessageDialog(null,"No ha cargado usuarios","Error",JOptionPane.ERROR_MESSAGE);
			    	if(diasEstadia.getText().equals("")) 
			    		JOptionPane.showMessageDialog(null,"No ha especificado los dias de estadia","Error",JOptionPane.ERROR_MESSAGE);
			    }				
			}
		});
		btnAdicionar.setBackground(Color.GRAY);
		btnAdicionar.setBounds(10, 574, 1159, 23);
		turismo.add(btnAdicionar);

		
		JPanel trabajo = new JPanel();
		trabajo.setForeground(new Color(255, 255, 255));
		trabajo.setBackground(new Color(51, 51, 51));
		tarjetero.addTab("Solicitar Visa de Trabajo", null, trabajo, null);
		trabajo.setLayout(null);
		
		JLabel lblEmpresa = new JLabel("Empresa");
		lblEmpresa.setForeground(Color.WHITE);
		lblEmpresa.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblEmpresa.setBounds(295, 22, 95, 25);
		trabajo.add(lblEmpresa);
		
		JLabel lblCargo = new JLabel("Cargo");
		lblCargo.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblCargo.setForeground(Color.WHITE);
		lblCargo.setBounds(592, 22, 66, 25);
		trabajo.add(lblCargo);
		
		empresa = new JTextField("");
		empresa.setBounds(400, 28, 178, 20);
		trabajo.add(empresa);
		empresa.setColumns(10);
		
		cargo = new JTextField("");
		cargo.setBounds(668, 28, 203, 20);
		trabajo.add(cargo);
		cargo.setColumns(10);
		
		JButton btnTarifasT = new JButton("Cargar Archivo de Tarifas");
		btnTarifasT.setBackground(Color.GRAY);
		btnTarifasT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser filesEmergente = null;
				int returnVal = JFileChooser.APPROVE_OPTION;
				if(tarifas == null) {
					filesEmergente = new JFileChooser();
					returnVal = filesEmergente.showOpenDialog(null);
				}
				if (returnVal == JFileChooser.APPROVE_OPTION) {
						if(tarifas == null) {
							tarifas = filesEmergente.getSelectedFile();
							String resultado = control.asignarVisas(tarifas);
							if(resultado == null) {
								tarifas = null;
								JOptionPane.showMessageDialog(null,"Archivo incompatible","Error",JOptionPane.ERROR_MESSAGE);
							}
							else { JOptionPane.showMessageDialog(null,resultado,"",JOptionPane.INFORMATION_MESSAGE);
								}
							
						}
				}
			}
		});
		btnTarifasT.setBounds(10, 58, 1159, 23);
		trabajo.add(btnTarifasT);
		
		JLabel lblNoDeSolicitud = new JLabel("No de Solicitud");
		lblNoDeSolicitud.setForeground(Color.WHITE);
		lblNoDeSolicitud.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNoDeSolicitud.setBounds(408, 97, 170, 25);
		trabajo.add(lblNoDeSolicitud);
		
		codSolT = new JTextField();
		codSolT.setEnabled(false);
		codSolT.setEditable(false);
		codSolT.setBounds(588, 103, 202, 20);
		trabajo.add(codSolT);
		codSolT.setColumns(10);
		
		table3 = new JTable();
		table3.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table3.setDefaultEditor(Object.class, null);
		table3.setModel(def);
		table3.setBackground(Color.GRAY);
		table3.setBounds(10, 155, 1159, 413);
		trabajo.add(table3);
		
		JButton btnCrearSolicitud = new JButton("Crear Solicitud");
		btnCrearSolicitud.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    if(!(empresa.getText().equalsIgnoreCase("")) && !(cargo.getText().equalsIgnoreCase("")) && !(table3.getSelectedRows().length==0) && !(def.getRowCount()==0) && tarifas!=null) {

						int sRows = table3.getSelectedRow();
						String pass = new String ((table3.getValueAt(sRows, 0)).toString());
						
						String resultado = control.trabajo(pass, empresa.getText().toString(), cargo.getText().toString());
						if(resultado.contains("codigo")) {
							JOptionPane.showMessageDialog(null,"Completado exitosamente","",JOptionPane.INFORMATION_MESSAGE);
							codSolT.setText(resultado.substring(6, resultado.length()));
						}
						else	
							JOptionPane.showMessageDialog(null,resultado,"",JOptionPane.ERROR_MESSAGE);
			    }
			    else {
			    	if(tarifas == null)
			    		JOptionPane.showMessageDialog(null,"No han cargado las tarifas","Error",JOptionPane.ERROR_MESSAGE);
			    	if(empresa.getText().equalsIgnoreCase(""))
						JOptionPane.showMessageDialog(null,"No ha especifiado la empresa","Error",JOptionPane.ERROR_MESSAGE);
			    	if(cargo.getText().equalsIgnoreCase(""))
						JOptionPane.showMessageDialog(null,"No ha especifiado el cargo","Error",JOptionPane.ERROR_MESSAGE);
					if(table3.getSelectedRows().length==0)
			    		JOptionPane.showMessageDialog(null,"No ha seleccionado usuarios solicitantes de visa","Error",JOptionPane.ERROR_MESSAGE);
			    	if(def.getRowCount()==0)
			    		JOptionPane.showMessageDialog(null,"No ha cargado usuarios","Error",JOptionPane.ERROR_MESSAGE);
			    }
			}
		});
		btnCrearSolicitud.setBackground(Color.GRAY);
		btnCrearSolicitud.setBounds(10, 579, 1159, 23);
		trabajo.add(btnCrearSolicitud);
		
		JPanel valor = new JPanel();
		valor.setForeground(new Color(255, 255, 255));
		valor.setBackground(new Color(51, 51, 51));
		tarjetero.addTab("Calcular Valor de la Visa", null, valor, null);
		valor.setLayout(null);
		
		JLabel lblBusquePor = new JLabel("Busqueda por:");
		lblBusquePor.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblBusquePor.setForeground(Color.WHITE);
		lblBusquePor.setBounds(300, 56, 147, 25);
		valor.add(lblBusquePor);
		
		final JComboBox<Object> busqueda = new JComboBox<Object>();
		busqueda.setBackground(Color.GRAY);
		busqueda.setModel(new DefaultComboBoxModel<Object>(new String[] {"", "NP - Numero de Pasaporte", "CP - Codigo de Solicitud"}));
		busqueda.setBounds(484, 56, 178, 20);
		valor.add(busqueda);
		
		JLabel lblNumero = new JLabel("Numero:");
		lblNumero.setForeground(Color.WHITE);
		lblNumero.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNumero.setBounds(360, 92, 87, 25);
		valor.add(lblNumero);
		
		numero = new JTextField();
		numero.addKeyListener(new KeyAdapter() {
			public void keyTyped(java.awt.event.KeyEvent e) {
				char c = e.getKeyChar();
				if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACKSPACE) || (c == KeyEvent.VK_DELETE))) {
					getToolkit().beep();
					e.consume();
				}
			}
		});
		numero.setBounds(484, 92, 178, 20);
		valor.add(numero);
		numero.setColumns(10);
		
		principal = new JTable();
		principal.setEnabled(false);
		principal.setBackground(Color.GRAY);
		principal.setModel(dtmP);
		principal.setBounds(10, 162, 1159, 43);
		valor.add(principal);
		
		secundario = new JTable();
		secundario.setEnabled(false);
		secundario.setBackground(Color.GRAY);
		secundario.setModel(dtmS);
		secundario.setBounds(10, 216, 1159, 298);
		valor.add(secundario);
		
		JLabel lblMoneda = new JLabel("Moneda Local:");
		lblMoneda.setForeground(Color.WHITE);
		lblMoneda.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblMoneda.setBounds(121, 525, 147, 32);
		valor.add(lblMoneda);
		
		JLabel lblValor = new JLabel("Valor en moneda local:");
		lblValor.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblValor.setForeground(Color.WHITE);
		lblValor.setBounds(37, 567, 231, 25);
		valor.add(lblValor);
		
		final JLabel monedaLocal = new JLabel("");
		monedaLocal.setForeground(Color.WHITE);
		monedaLocal.setHorizontalAlignment(SwingConstants.LEFT);
		monedaLocal.setFont(new Font("Tahoma", Font.BOLD, 20));
		monedaLocal.setBounds(279, 525, 301, 32);
		valor.add(monedaLocal);
		
		final JLabel valorLocal = new JLabel("");
		valorLocal.setForeground(Color.WHITE);
		valorLocal.setFont(new Font("Tahoma", Font.BOLD, 20));
		valorLocal.setBounds(278, 567, 302, 25);
		valor.add(valorLocal);
		
		JLabel lblTasaDeCambio = new JLabel("Tasa de cambio:");
		lblTasaDeCambio.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblTasaDeCambio.setForeground(Color.WHITE);
		lblTasaDeCambio.setBounds(648, 525, 163, 32);
		valor.add(lblTasaDeCambio);
		
		JLabel lblPsc = new JLabel("MPSC:");
		lblPsc.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblPsc.setForeground(Color.WHITE);
		lblPsc.setBounds(747, 567, 64, 25);
		valor.add(lblPsc);
		
		final JLabel tasaCambio = new JLabel("");
		tasaCambio.setHorizontalAlignment(SwingConstants.LEFT);
		tasaCambio.setForeground(Color.WHITE);
		tasaCambio.setFont(new Font("Tahoma", Font.BOLD, 20));
		tasaCambio.setBounds(821, 525, 308, 32);
		valor.add(tasaCambio);
		
		final JLabel PSC = new JLabel("");
		PSC.setHorizontalAlignment(SwingConstants.LEFT);
		PSC.setFont(new Font("Tahoma", Font.BOLD, 20));
		PSC.setForeground(Color.WHITE);
		PSC.setBounds(819, 567, 310, 25);
		valor.add(PSC);
		
		JButton btnCalcularValor = new JButton("Calcular Valor de la Visa");
		btnCalcularValor.setBackground(Color.GRAY);
		btnCalcularValor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String resultado = new String("");
				if(!numero.getText().equals("")) {
					if(busqueda.getSelectedItem().toString().contains("NP"))
						resultado = control.calcularValorVisa(numero.getText().toString());
					if(busqueda.getSelectedItem().toString().contains("CP"))
						resultado = control.calcularValorVisa(Integer.parseInt(numero.getText().toString()));
					if(busqueda.getSelectedItem().toString().equals(""))
						JOptionPane.showMessageDialog(null,"Seleccione un metodo de busqueda","Error",JOptionPane.ERROR_MESSAGE);
					if(!resultado.contains("*") && !resultado.equals("")) {
						while(dtmP.getRowCount()>0) {
							dtmP.removeRow(0);
						}
						while(dtmS.getRowCount()>0) {
							dtmS.removeRow(0);
						}
						
						String [] conjuntos = resultado.split("#");
						String [] datos = conjuntos[0].split("_");
						Object [] row = new Object[6];
						row [0] = datos [0];
						row [1] = datos [1];
						row [2] = datos [2];
						row [3] = datos [3];
						row [4] = datos [4];
						row [5] = datos [5];
						dtmP.addRow(row);
						for(int i=1;i<(conjuntos.length)-1;i++) {
							datos = conjuntos[i].split("_");
							row [0] = datos [0];
							row [1] = datos [1];
							row [2] = datos [2];
							row [3] = datos [3];
							row [4] = datos [4];
							row [5] = datos [5];
							dtmS.addRow(row);
						}
						datos = conjuntos[(conjuntos.length)-1].split("_");
						monedaLocal.setText(datos[0]);
						valorLocal.setText(datos[1]);
						tasaCambio.setText(datos[2]);
						PSC.setText(datos[3]);
					}
					else {
						if(!resultado.equals(""))
						JOptionPane.showMessageDialog(null,resultado,"Error",JOptionPane.ERROR_MESSAGE);
					}
				}
				else {
					JOptionPane.showMessageDialog(null,"Ingrese un numero","Error",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnCalcularValor.setBounds(10, 128, 1159, 23);
		valor.add(btnCalcularValor);
		
		JPanel citas = new JPanel();
		citas.setForeground(new Color(255, 255, 255));
		citas.setBackground(new Color(51, 51, 51));
		tarjetero.addTab("Reportar Citas", null, citas, null);
		citas.setLayout(null);
		
		JLabel lblFecha = new JLabel("Fecha:");
		lblFecha.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblFecha.setForeground(Color.WHITE);
		lblFecha.setBounds(10, 51, 67, 25);
		citas.add(lblFecha);
		
		fecha = new JTextField();
		fecha.setBounds(87, 51, 155, 25);
		citas.add(fecha);
		fecha.setColumns(10);
		
		JLabel lblAaaammdd = new JLabel("aaaa  -  mm  -  dd");
		lblAaaammdd.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAaaammdd.setForeground(Color.WHITE);
		lblAaaammdd.setBounds(87, 78, 155, 14);
		citas.add(lblAaaammdd);
		
		citasT = new JTable();
		citasT.setBackground(Color.GRAY);
		citasT.setModel(dtmC);
		citasT.setBounds(10, 153, 1159, 456);
		citas.add(citasT);
		
		JButton btnGenerarReporte = new JButton("Generar Reporte");
		btnGenerarReporte.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String resultado = control.reportarCitas(fecha.getText().toString());
					if(!(resultado.contains("*")) && !(resultado.equals(""))) {
						while(dtmC.getRowCount()>0) {
							dtmC.removeRow(0);
						}
						String [] conjuntos = resultado.split("\r\n");
						String [] datos;
						Object [] row = new Object [4];
						for(int i=0; i<conjuntos.length;i++) {
							datos = conjuntos[i].split("_");
							row [0] = datos [0];
							row [1] = datos [1];
							row [2] = datos [2];
							row [3] = datos [3];
							dtmC.addRow(row);
						}
					}
					else {
						if(resultado.contains("*"))
							JOptionPane.showMessageDialog(null,resultado,"Error",JOptionPane.ERROR_MESSAGE);
						else
							JOptionPane.showMessageDialog(null,"No hay citas para la fecha especificada","Error",JOptionPane.ERROR_MESSAGE);
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnGenerarReporte.setBackground(Color.GRAY);
		btnGenerarReporte.setBounds(10, 119, 1159, 23);
		citas.add(btnGenerarReporte);
		
		JPanel lista = new JPanel();
		lista.setForeground(new Color(255, 255, 255));
		lista.setBackground(new Color(51, 51, 51));
		tarjetero.addTab("Lista de Beneficiarios", null, lista, null);
		lista.setLayout(null);
		
		
		listaB = new JTable();
		listaB.setEnabled(false);
		listaB.setModel(dtmL);
		listaB.setBackground(Color.GRAY);
		listaB.setBounds(10, 61, 1159, 483);
		lista.add(listaB);
		
		txtTotal = new JTextField();
		txtTotal.setEnabled(false);
		txtTotal.setBounds(951, 572, 218, 20);
		lista.add(txtTotal);
		txtTotal.setColumns(10);
		
		JButton btnListarBeneficiarios = new JButton("Listar Beneficiarios");
		btnListarBeneficiarios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String resultado = control.listarBeneficiarios();
				if(!(resultado.contains("*"))){
					while(dtmL.getRowCount()>0) {
						dtmL.removeRow(0);
					}
					String [] conjuntos = resultado.split("\r\n");
					String [] datos;
					Object [] row = new Object [3];
					double total = 0;
					for(int i=0; i<conjuntos.length;i++) {
						datos = conjuntos[i].split("_");
						row [0] = datos [0];
						row [1] = datos [1];
						row [2] = datos [2];
						total = total + Double.parseDouble(datos[2]);
						dtmL.addRow(row);
					}
					txtTotal.setText(Double.toString(total));
				}
				else {
					JOptionPane.showMessageDialog(null,resultado,"Error",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnListarBeneficiarios.setBackground(Color.GRAY);
		btnListarBeneficiarios.setBounds(10, 27, 1159, 23);
		lista.add(btnListarBeneficiarios);
		
		JLabel lblEl = new JLabel("Valor total que se dejo de recaudar en MPSC :");
		lblEl.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblEl.setForeground(Color.WHITE);
		lblEl.setBounds(479, 567, 462, 23);
		lista.add(lblEl);
		
	}
}
