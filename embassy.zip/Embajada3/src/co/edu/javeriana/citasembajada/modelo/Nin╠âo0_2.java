package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;

public class Niño0_2 extends Usuario implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String acudiente;

	/**
	 * @param solicitante vetor de string con informacion de el usuario
	 * constructor con la informacion del usuario
	 */
	public Niño0_2(String[] solicitante) {
		super(solicitante);
		setAcudiente(solicitante[6]);
	}

	/* (non-Javadoc)
	 * @see co.edu.javeriana.citasembajada.modelo.Usuario#calcularValorVisa()
	 * calculador de visa
	 */
	@Override
	public double calcularValorVisa() {
		return 0;
	}

	/**
	 * @return string acudiente
	 * get de acudiente
	 */
	public String getInfo() {
		return acudiente;
	}

	/**
	 * @param acudiente string acudiente
	 * set de acudiente
	 */
	public void setAcudiente(String acudiente) {
		this.acudiente = acudiente;
	}

}
