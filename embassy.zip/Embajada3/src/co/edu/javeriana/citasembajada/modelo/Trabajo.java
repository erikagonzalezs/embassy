package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;

public class Trabajo extends Visa implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param descripcion requisitos visa
	 * @param datos datos de la visa
	 * constructor de visas
	 */
	public Trabajo(String[] datos) {
		super(datos);
	}
	
	/**
	 * @param soli objeto Solicitud para adicionar
	 * @param e Empresa
	 * @param c cargo
	 * metodo que agrega una solicitud
	 */
	public void agregarSolicitud(Solicitud soli, String e, String c){
		soli.setEmpresa(e);
		soli.setCargo(c);
		agregarSolicitud(soli);
		
	}
}
