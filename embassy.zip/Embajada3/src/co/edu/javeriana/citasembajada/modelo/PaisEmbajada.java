package co.edu.javeriana.citasembajada.modelo;

public enum PaisEmbajada {
		USA,FRANCIA,CHILE,JAPON,AUSTRALIA;
}
