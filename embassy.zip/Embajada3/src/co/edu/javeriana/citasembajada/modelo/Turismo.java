package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;

public class Turismo extends Visa implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param descripcion requisitos visa
	 * @param datos datos de la visa
	 * constructor de visas
	 */
	public Turismo(String[] datos) {
		super(datos);
	}
	
	/**
	 * @param soli objeto solicitud
	 * @param dias dias de estadia
	 * metodo que agrega una solicitud
	 */
	public void agregarSolicitud(Solicitud soli, int dias){
		soli.setDiasEstadia(dias);
		agregarSolicitud(soli);
		
	}
}
