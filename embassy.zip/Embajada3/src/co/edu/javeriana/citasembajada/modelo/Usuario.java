/**
 * 
 */
package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public abstract class Usuario implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected String nombre;
	protected String numPasaporte;
	protected String email;
	protected LocalDate fechaNacimiento;
	protected String paisNacimiento;
	protected String ciudadNacimiento;
	protected Solicitud solicitud;
	
	/**
	 * @param solicitante string con datos del usuario
	 * constructor 
	 */
	public Usuario(String[] solicitante) {
		nombre = solicitante[1];
		numPasaporte = solicitante[0].replace(" ", "");
		email = solicitante [5];
		DateTimeFormatter dtf =DateTimeFormatter.ofPattern("yyyy-MM-dd");
		fechaNacimiento= LocalDate.parse(solicitante[4],dtf);		
		paisNacimiento = solicitante[2];
		ciudadNacimiento = solicitante[3];
	}
	
	/**
	 * @return double valor de visa
	 * calcula el valor de la visa
	 */
	public abstract double calcularValorVisa();
	
	/**
	 * @return informacion adicional
	 */
	public abstract String getInfo();

	/**
	 * @return nombre
	 * getter atributo nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @return numpasaporte
	 * getter atributo numero de pasaporte
	 */
	public String getNumPasaporte() {
		return numPasaporte;
	}

	/**
	 * @return email
	 * getter atributo email
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * @return fecha de naciemiento
	 * getter atributo fechanacimiento
	 */
	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}
	
	/**
	 * @return pais natal
	 * getter atributo paisnacimiento
	 */
	public String getPaisNacimiento() {
		return paisNacimiento;
	}
	
	/**
	 * @return ciudad natal
	 * getter atributo ciudadnacimiento
	 */
	public String getCiudadNacimiento() {
		return ciudadNacimiento;
	}
	
	/**
	 * @return tipo de visa solicitada
	 * obtien el tipo de visa solicitada
	 */
	public String getSolicitudVisa() {
		return solicitud.getTipoVisa();
	}
	
	/**
	 * @return tama�o lista de usuarios con su misma solicitud
	 * metodo que obtiene el tama�o de la lista de solicitantes donde esta ese usuario
	 */
	public int getSolicitudes() {
		try {
		return solicitud.getTamList();
		}catch (Exception e){
			System.out.println("No hay solicitudes de visa");
			return -1;
		}
	}
	
	/**
	 * @return codigo de solicitud
	 * metodo que obtiene el codigo de solicitud del usuario
	 */
	public int getCodigo() {
		return solicitud.getCodigo();
	}
	
	/**
	 * @param solicitud objeto tipo Solicitud
	 * setter atributo solicitud
	 */
	public void setSolicitud(Solicitud solicitud) {
		this.solicitud=solicitud;
	}

}
