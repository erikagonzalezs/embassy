package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;

public class Estudiante extends Visa implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Escolaridad nivel;

	/**
	 * @param descripcion requisitos visa
	 * @param datos datos de la visa
	 * constructor de visas
	 */
	public Estudiante(String[] datos) {
		super(datos);
	}
	
	/**
	 * @param soli objeto Solicitud para adicionar
	 * @param e Escolaridad
	 * @param i Institucion
	 * metodo que agrega una solicitud
	 */
	public void agregarSolicitud(Solicitud soli, String e, String i){
		soli.setEscolaridad(e);
		soli.setInstitucion(i);
		agregarSolicitud(soli);
		
	}

	/**
	 * @return enumerado escolaridad
	 */
	public Escolaridad getNivel() {
		return nivel;
	}

	/**
	 * @param nivel set escolaridad
	 */
	public void setNivel(Escolaridad nivel) {
		this.nivel = nivel;
	}
}
