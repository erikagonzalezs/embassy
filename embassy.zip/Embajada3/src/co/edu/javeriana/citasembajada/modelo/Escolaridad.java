package co.edu.javeriana.citasembajada.modelo;

public enum Escolaridad {
	PREESCOLAR,PRIMARIA,BACHILLERATO,UNIVERSIDAD;
}
