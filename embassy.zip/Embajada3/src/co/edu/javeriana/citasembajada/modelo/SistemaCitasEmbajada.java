package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SistemaCitasEmbajada implements ISistemaCitasEmbajada,Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String paisEmbajada;
	private String moneda;
	private double cambioOficial;
	private float impuesto;
	private Map<String, Usuario> usuario = new HashMap<String, Usuario>();
	private Map<String, Requisito> requisito = new HashMap<String, Requisito>();
	private List<Visa> visa = new ArrayList<Visa>();
	private List<Solicitud> solicitud = new ArrayList<Solicitud>();
	private PaisEmbajada pais;

	/**
	 * Constructor por defecto
	 */
	public SistemaCitasEmbajada() {
		usuario = new HashMap<String, Usuario>();
		visa = new ArrayList<Visa>();
		solicitud = new ArrayList<Solicitud>();
	}
	
	/**
	 * @param sistema: Vector con los parametros
	 * Constructor llena atributos
	 */
	public SistemaCitasEmbajada(String[] sistema) {
		 paisEmbajada = sistema [1];
		 moneda = sistema [2];
		 cambioOficial = Double.parseDouble(sistema [4]);
		 impuesto = Float.parseFloat(sistema [3]);
	}
	
	/**
	 * @param tvisa: Tipo de visa a buscar
	 * @return objeto tipo Visa
	 * Metodo que busca una visa del mismo tipo
	 */
	private Visa buscarVisa(String tvisa) {
		for(Visa refvisa : visa) {
			if(refvisa!=null) {
				if(tvisa.equalsIgnoreCase("Turismo")) 
					if(refvisa instanceof Turismo) 
						return refvisa;
				if(tvisa.equalsIgnoreCase("Trabajo")) 
					if(refvisa instanceof Trabajo) 
						return refvisa;
				if(tvisa.equalsIgnoreCase("Estudiante")) 
					if(refvisa instanceof Estudiante) 
						return refvisa;
				if(tvisa.equalsIgnoreCase("Conyuge")) 
					if(refvisa instanceof Conyuge) 
						return refvisa;
			}
		}
		return null;
	}
	
	/**
	 * @param pass Numero de pasaporte
	 * @return objeto tipo Usuario
	 * El metodo busca un usuario con el numero de pasaporte especificado
	 */
	private Usuario buscarUsuario(String pass) {
		if(usuario.containsKey(pass)) {
			return usuario.get(pass);
		}
		return null;
	}
	
	/**
	 * @param sol Objeto tipo solicitud
	 * asigna una fecha a la solicitud
	 */
	public void asignarFechaHora (Solicitud sol) {
		sol.setFecha(LocalDate.now());
	}

	
	/**
	 * @param cod Codigo de la solicitud
	 * @return retorna objeto Solicitud
	 * Busca el objeto Solicitud con el codigo solicitud
	 */
	public Solicitud buscarSolicitud(int cod) {
		for(Solicitud solicitante : solicitud){
			if(solicitante != null) {
				if(cod == solicitante.getCodigo()) {
					return solicitante;
				}
			}
		}
		return null;
	}
	
	/**
	 * @param pass pasaporte
	 * @param tvisa tipo de visa
	 * @return retorna el codigo de la nueva solicitud
	 * Metodo que crea una nueva solicitud para un usuario 
	 */
	public String agregarSolicitud(String pass, String tvisa, int dias, String e, String i_c) {
		
		Usuario user = buscarUsuario(pass);
		Visa tipoVisa = buscarVisa(tvisa);
		
		
		if(user==null) {
			return "El pasaporte no se encontro";
		}

		if(tipoVisa==null) {
			return "La visa no se encontro";
		}
		
		Solicitud solicitudes = new Solicitud ();
		asignarFechaHora(solicitudes);
		
		if(tipoVisa instanceof Turismo) {
			Turismo v = (Turismo) tipoVisa;
			v.agregarSolicitud(solicitudes,dias);
		}
		if(tipoVisa instanceof Trabajo) {
			Trabajo v = (Trabajo) tipoVisa;
			v.agregarSolicitud(solicitudes, e, i_c);
		}
		if(tipoVisa instanceof Estudiante) {
			Estudiante v = (Estudiante) tipoVisa;
			v.agregarSolicitud(solicitudes, e, i_c);
		}
		if(tipoVisa instanceof Conyuge) {
			Conyuge v = (Conyuge) tipoVisa;
			v.agregarSolicitud(solicitudes);
		}
		
		solicitudes.setVisa(tipoVisa);
		solicitudes.agregarUsuarioSolicitud(user);
		user.setSolicitud(solicitudes);
		solicitud.add(solicitudes);
		String codigo = new String ("codigo" + Integer.toString(solicitudes.getCodigo()));
		return codigo;
	}
	/* (non-Javadoc)
	 * @see co.edu.javeriana.citasembajada.modelo.ISistemaCitasEmbajada#agregarSolicitud(java.lang.String[], int)
	 */
	public String agregarSolicitud(String [] otrosSolicitantes, int cod) {
		
		boolean bool = true;
		Solicitud solicitudes = buscarSolicitud(cod);
		String codigo = new String ("");
		
		if(solicitudes == null) {
			return "No se encontro el numero de solicitud";
		}
		
		for(int j=0;j<otrosSolicitantes.length;j++) {
			for(int i=0; i<solicitudes.getTamList(); i++) {
				if(solicitudes.getNumPassUsuario(i).equalsIgnoreCase(otrosSolicitantes[j])) {
					bool = false;
				}
			}
			if(bool == true) {
				Usuario user = buscarUsuario(otrosSolicitantes[j]);
				if(user!=null) {
					solicitudes.agregarUsuarioSolicitud(user);
					user.setSolicitud(solicitudes);
				}
				if(user==null) {
					codigo = new String (codigo + "El pasaporte " + otrosSolicitantes[j] + " no existe\n");
				}			
			}
			else {
				codigo = new String ("El pasaporte " + otrosSolicitantes[j] + " no se agrego porque ya estaba\n");
				bool = true;
			}
		}
		return codigo;
	}
	
	/**
	 * @param pass pasaporte
	 * @param otrosSolicitantes vector con los otros solicitantes que viajan con el usuario
	 * @param tvisa tipo de visa
	 * @return retorna el codigo de la nueva solicitud
	 * Metetodo que crea una solicitud con varios usuarios
	 */
	public String agregarSolicitud(String pass,String [] otrosSolicitantes, String tvisa, int dias, String e, String i_c) {
			
		Usuario user = buscarUsuario(pass);
		Visa tipoVisa = buscarVisa(tvisa);
		
		
		if(user==null) {
			return "El pasaporte no se encontro";
		}

		if(tipoVisa==null) {
			return "La visa no se encontro";
		}
		
		Solicitud solicitudes = new Solicitud ();
		asignarFechaHora(solicitudes);
		
		if(tipoVisa instanceof Turismo) {
			Turismo v = (Turismo) tipoVisa;
			v.agregarSolicitud(solicitudes,dias);
		}
		if(tipoVisa instanceof Trabajo) {
			Trabajo v = (Trabajo) tipoVisa;
			v.agregarSolicitud(solicitudes, e, i_c);
		}
		if(tipoVisa instanceof Estudiante) {
			Estudiante v = (Estudiante) tipoVisa;
			v.agregarSolicitud(solicitudes, e, i_c);
		}
		if(tipoVisa instanceof Conyuge) {
			Conyuge v = (Conyuge) tipoVisa;
			v.agregarSolicitud(solicitudes);
		}
		
		solicitudes.setVisa(tipoVisa);
		solicitudes.agregarUsuarioSolicitud(user);
		user.setSolicitud(solicitudes);
		solicitud.add(solicitudes);
		String codigo = new String ("codigo" + Integer.toString(solicitudes.getCodigo()));
			
			for(int i=0; i<otrosSolicitantes.length; i++) {
				if(!pass.equalsIgnoreCase(otrosSolicitantes[i])) {
						user = buscarUsuario(otrosSolicitantes[i]);
					if(user!=null) {
						solicitudes.agregarUsuarioSolicitud(user);
						user.setSolicitud(solicitudes);
					}
					if(user==null) {
						codigo = new String ("Algunos pasaportes no se agregaron porque no existen, " + codigo);
					}
				}
			}
			return codigo;
	}
	
	/* (non-Javadoc)
	 * @see co.edu.javeriana.citasembajada.modelo.ISistemaCitasEmbajada#calcularValorVisa(java.lang.String)
	 * metodo que coordina el calculo de visa a partir del pasaporte
	 */
	public String calcularValorVisa(String pass) {
		double valorVisa = 0;
		double impuesto = 0;
		double valorTotal = 0;
		double valorTotalVisa=0;
		
		int tamaño = getUsuariosSolicitudes(pass);
		if(tamaño == -1) {
			return "*Pasaporte invalido*";
		}
		
		int codigo = getCodigoSolicitud(pass);
		String [] datosUsuario = getUsuarioDatos(pass);
		String resultado = new String (datosUsuario[0] + "_" + datosUsuario[1] + "_" + datosUsuario[2] + "_" + datosUsuario[3] + "_" + datosUsuario[4] + "_" + datosUsuario[5] +
									   "#" +
								getVisaSolicitante(codigo) + 
								       "#");
		for(int i=0; i<tamaño; i++) {
			LocalDate fecha = getFechaSolicitante(codigo, i);
			if(fecha == null) {
				return "*Sin codigo de reserva*";
			}
			int edad = Utils.getEdad(fecha);
			if(edad<=2) {
				valorVisa = calcularValorVisa(codigo, 10);
				impuesto = getImpuesto(valorVisa);
				valorTotal = valorVisa + impuesto;
			}
			if(edad>2 && edad<=12) {
				double incremento = 0;
				if(buscarVisa(getVisaSolicitante(codigo)) instanceof Turismo) {
					incremento = 20;
				}
				if(buscarVisa(getVisaSolicitante(codigo)) instanceof Estudiante) {
					valorVisa = calcularValorVisa(codigo, 70 );
					impuesto = getImpuesto(valorVisa);
					valorTotal = valorVisa + impuesto;
				}
				if(buscarVisa(getVisaSolicitante(codigo)) instanceof Trabajo || buscarVisa(getVisaSolicitante(codigo)) instanceof Conyuge || buscarVisa(getVisaSolicitante(codigo)) instanceof Turismo) {
					double dcto = 100 - (5*(18-edad));
					valorVisa = calcularValorVisa(codigo, dcto - incremento );
					impuesto = getImpuesto(valorVisa);
					valorTotal = valorVisa + impuesto;
				}

			}
			if(edad>12 && edad<=65) {
				
				valorVisa = calcularValorVisa(codigo, 100);
				impuesto = getImpuesto(valorVisa);
				valorTotal = valorVisa + impuesto;
			}
			if(edad>65) {
				double incremento = 0;
				if(buscarVisa(getVisaSolicitante(codigo)) instanceof Turismo) {
					incremento = 10;
				}
				valorVisa = calcularValorVisa(codigo, 75 - incremento);
				impuesto = getImpuesto(valorVisa);
				valorTotal = valorVisa + impuesto;
			}
			resultado = new String (resultado + getPassSolicitud(codigo, i) + "_" + getSolicitudNombre(codigo, i) + "_" + getFechaSolicitante(codigo, i) + "_" + String.format("%.0f", valorVisa) + "+" + String.format("%.0f", impuesto) + "_" + String.format("%.0f", valorTotal) + "#");
			valorTotalVisa = valorTotalVisa + valorTotal;
		}
	resultado = new String(resultado + 
						   getMoneda() +"_"+String.format("%.0f", valorTotalVisa) + "_" + String.format("%.0f", getTasaCambio()) + "_" +String.format("%.0f", valorTotalVisa*getTasaCambio()));
	return resultado;
	}
	
	/* (non-Javadoc)
	 * @see co.edu.javeriana.citasembajada.modelo.ISistemaCitasEmbajada#calcularValorVisa(int)
	 * etodo que coordina el calculo de visa a partir del codigo de reserva
	 */
	public String calcularValorVisa(int codigo) {
		double valorVisa = 0;
		double impuesto = 0;
		double valorTotal = 0;
		double valorTotalVisa=0; 
		
		int tamaño = getUsuariosSolicitudes(codigo);
		if(tamaño == -1) {
			return "*Codigo invalido*";
		}
		
		String [] datosUsuario = getUsuarioDatos(codigo);
		String resultado = new String (datosUsuario[0] + "_" + datosUsuario[1] + "_" + datosUsuario[2] + "_" + datosUsuario[3] + "_" + datosUsuario[4] + "_" + datosUsuario[5] + 
								       "#");
		for(int i=0; i<tamaño; i++) {
			LocalDate fecha = getFechaSolicitante(codigo, i);
			if(fecha == null) {
				return "*Sin codigo de reserva*";
			}
			int edad = Utils.getEdad(fecha);
			if(edad<=2) {
				valorVisa = calcularValorVisa(codigo, 10);
				impuesto = getImpuesto(valorVisa);
				valorTotal = valorVisa + impuesto;
			}
			if(edad>2 && edad<=12) {
				double incremento = 0;
				if(buscarVisa(getVisaSolicitante(codigo)) instanceof Turismo) {
					incremento = 20;
				}
				if(buscarVisa(getVisaSolicitante(codigo)) instanceof Estudiante) {
					valorVisa = calcularValorVisa(codigo, 70 );
					impuesto = getImpuesto(valorVisa);
					valorTotal = valorVisa + impuesto;
				}
				if(buscarVisa(getVisaSolicitante(codigo)) instanceof Trabajo || buscarVisa(getVisaSolicitante(codigo)) instanceof Conyuge || buscarVisa(getVisaSolicitante(codigo)) instanceof Turismo) {
					double dcto = 100 - (5*(18-edad));
					valorVisa = calcularValorVisa(codigo, dcto - incremento );
					impuesto = getImpuesto(valorVisa);
					valorTotal = valorVisa + impuesto;
				}

			}
			if(edad>12 && edad<=65) {
				
				valorVisa = calcularValorVisa(codigo, 100);
				impuesto = getImpuesto(valorVisa);
				valorTotal = valorVisa + impuesto;
			}
			if(edad>65) {
				double incremento = 0;
				if(buscarVisa(getVisaSolicitante(codigo)) instanceof Turismo) {
					incremento = 10;
				}
				valorVisa = calcularValorVisa(codigo, 75 - incremento);
				impuesto = getImpuesto(valorVisa);
				valorTotal = valorVisa + impuesto;
			}
			resultado = new String (resultado + getPassSolicitud(codigo, i) + "_" + getSolicitudNombre(codigo, i) + "_" + getFechaSolicitante(codigo, i) + "_" + String.format("%.0f", valorVisa) + "_" + String.format("%.0f", impuesto) + "_" + String.format("%.0f", valorTotal) + "#");
			valorTotalVisa = valorTotalVisa + valorTotal;
		}
	resultado = new String(resultado + 
							getMoneda() +"_"+String.format("%.0f", valorTotalVisa) + "_" + String.format("%.0f", getTasaCambio()) + "_" +String.format("%.0f", valorTotalVisa*getTasaCambio()));
	return resultado;
	}
	
	/**
	 * @param cod Codigo de solicitud
	 * @param descuento Cantidad de descuento por edad
	 * @return retorna valor de la visa para un solicitante
	 */
	public double calcularValorVisa(int cod, double descuento) {
		
		Solicitud sol = buscarSolicitud(cod);
		Visa visa = buscarVisa(sol.getTipoVisa());
		
		return ((visa.getValor()*descuento)/100);
	}
	
	/* (non-Javadoc)
	 * @see co.edu.javeriana.citasembajada.modelo.ISistemaCitasEmbajada#listarBeneficiados()
	 * metodo que calcula todos los beneficiados sin descuento para saber lo que se dejo de recaudar
	 */
	public ArrayList<String> listarBeneficiados(){
		double total = 0;
		List <String> orden = new ArrayList <String> ();
		List <String> desorden = new ArrayList <String> ();
		orden.add("Lista de beneficiarios\r\n" + 
				"#numPass----nombre-----valorTotal (pesos)\r\n");
		if(solicitud.isEmpty()) {
			orden.add("*No hay solicitudes");
			return (ArrayList<String>) orden;
		}
		for(Solicitud s : solicitud) {
			if(s != null) {
				int tam = s.getTamList();
				Visa v = buscarVisa(s.getTipoVisa());
				for(int i=0; i<tam; i++) {
					if(s.getUsuario(i) instanceof Niño0_2 || s.getUsuario(i) instanceof Niño2_12 || s.getUsuario(i) instanceof AdultoMayor) {
						desorden.add(s.getNombreUsuario(i)+"*"+s.getNumPassUsuario(i)+"*"+v.getValor()+"\r\n");
						total = total + v.getValor();
					}
				}
			}
		}
		if(!desorden.isEmpty()) {
			Collections.sort(desorden);
			for(String s : desorden) {
				if(s!=null) {
					String [] split = s.split("\\*");
					orden.add(split[1] + "_" + split[0] + "_" + split [2]);
				}
			}
			orden.add("El valor total en pesos que se dej� de recaudar por visas de beneficiados es: " + total);
		}else {
			orden.add("*No hay solicitudes con beneficiarios");
		}
		return (ArrayList<String>) orden;
	}
	
	/**
	 * @param usuarios array de vetores string con todos los solicitantes y sus datos
	 * @return mensaje de exito o error
	 * Metodo que agrega a todos los solicitantes y sus datos
	 */
	public String setUsuario(List<String[]> usuarios) {
		try {
		String resultado = new String ("Completado con exito\n");
		boolean bool=true;
		for(int i=0; i<usuarios.size();i++) {
				if(usuario.containsKey((usuarios.get(i))[0])) {
					bool=false;
				}
		if(bool==true) {
			String[] u = usuarios.get(i);
			
				if(Utils.getEdad(Utils.stringToLocalDate(u[4]))<=2) {
					Niño0_2 solicitante = new Niño0_2 (u);
					usuario.put(u[0].replaceAll(" ", ""), solicitante);
				}
				if(Utils.getEdad(Utils.stringToLocalDate(u[4]))>2 && Utils.getEdad(Utils.stringToLocalDate(u[4]))<=12) {
					Niño2_12 solicitante = new Niño2_12 (u);
					usuario.put(u[0].replaceAll(" ", ""), solicitante);
				}
				if(Utils.getEdad(Utils.stringToLocalDate(u[4]))>12 && Utils.getEdad(Utils.stringToLocalDate(u[4]))<=65) {
					Adulto solicitante = new Adulto (u);
					usuario.put(u[0].replaceAll(" ", ""), solicitante);
				}
				if(Utils.getEdad(Utils.stringToLocalDate(u[4]))>65) {
					AdultoMayor solicitante = new AdultoMayor (u);
					usuario.put(u[0].replaceAll(" ", ""), solicitante);
				}
	
			}
		else {
			resultado = new String ("Algunos usuarios no se agregaron por tener el numero de pasaporte igual\n");
			}
		bool = true;
		}
		/*for(Usuario u1 : usuario) {
			System.out.println(u1.getNombre());
			if(u1 instanceof Ni�o0_2) {
				System.out.println(((Ni�o0_2) u1).getAcudiente());
			}
			if(u1 instanceof Ni�o2_12) {
				System.out.println(((Ni�o2_12) u1).getEscolaridad());
			}
		}*/
		return resultado;
		}
		catch (Exception e)
		{
			System.out.println("Existe un error en el patron del archivo Solicitantes: "+e);			
		}
		return "No se puede completar la accion";
	}
	
	/**
	 * @param cod lista con los datos de las tarifas de visa
	 * @return mensaje de error/exito
	 */
	public String setVisa(List<String[]> cod) {
		try {
		String resultado = new String ("Archivo cargado con exito\n");
		boolean bool=true;
		for(int i=0; i<cod.size(); i++) {
			String [] comparar = cod.get(i);
			for(int j=0; j<visa.size();j++) {
				String [] compmov = cod.get(j);
				if(comparar[0].equalsIgnoreCase(compmov[0])){
					bool=false;
				}
			}
			
		if(bool==true) {
					if((comparar[1].replaceAll(" ", "")).equalsIgnoreCase("Turismo")) {
						Turismo t = new Turismo(comparar);
						visa.add(t);
					}
					if((comparar[1].replaceAll(" ", "")).equalsIgnoreCase("Trabajo")) {
						Trabajo t = new Trabajo(comparar);
						visa.add(t);
					}
					if((comparar[1].replaceAll(" ", "")).equalsIgnoreCase("Estudiante")) {
						Estudiante t = new Estudiante(comparar);
						visa.add(t);
					}
					if((comparar[1].replaceAll(" ", "")).equalsIgnoreCase("Conyuge")) {
						Conyuge t = new Conyuge (comparar);
						visa.add(t);
					}	
			}
		else {
			resultado = new String ("Algunas visas no se cargaron por tener el ID igual\n");
			}
		bool = true;
		}
		return resultado;
		}
		catch (Exception e)
		{
			return null;			
		}
	}
	
	
	/**
	 * @param visas array de vetores string con todos los tipos de visa y sus requisitos
	 * @param cod array de vectores string con datos de visa
	 * @return mensaje de error  o exito
	 * Metodo que instancia los tipos de visa y sus requisitos
	 */
/*	public String setVisa(List<String[]> visas, List<String[]> cod) {
		try {
		String resultado = new String ("Completado con exito\n");
		boolean bool=true;
		for(int i=0; i<cod.size(); i++) {
			String [] comparar = cod.get(i);
			for(int j=0; j<visa.size();j++) {
				String [] compmov = cod.get(j);
				if(comparar[0].equalsIgnoreCase(compmov[0])){
					bool=false;
				}
			}
			
		if(bool==true) {
			for(int j=0; j<visas.size(); j+=2) {
				String [] tipo = visas.get(j);
				if(comparar[1].contains(tipo[0])) {
					if(tipo[0].equalsIgnoreCase("Turismo")) {
						Turismo t = new Turismo(visas.get(j+1), comparar);
						visa.add(t);
					}
					if(tipo[0].equalsIgnoreCase("Trabajo")) {
						Trabajo t = new Trabajo(visas.get(j+1), comparar);
						visa.add(t);
					}
					if(tipo[0].equalsIgnoreCase("Estudiante")) {
						Estudiante t = new Estudiante(visas.get(j+1), comparar);
						visa.add(t);
					}
					if(tipo[0].equalsIgnoreCase("Conyuge")) {
						Conyuge t = new Conyuge (visas.get(j+1), comparar);
						visa.add(t);
					}
				}
			}	
			}
		else {
			resultado = new String ("Algunos usuarios no se agregaron por tener el ID igual\n");
			}
		bool = true;
		}
		return resultado;
		}
		catch (Exception e)
		{
			System.out.println("No se puede completar la accion: "+e);			
		}
		return "No se puede completar la accion";
	}/*
	
	
	
	/**
	 * @param fecha especificado para la consulta de solicitudes
	 * @return todos las solicitudes para la fecha
	 * Metodo que busca entre las solicitudes cuales estan designadas para la fecha
	 */
	public String getSolicitud(LocalDate fecha) {
		String resultado = new String ("");
		for(Solicitud fechas : solicitud) {
			if(fechas!=null) {
				if(fecha.isEqual(fechas.getFecha())) {
					
					for(int i=0; i<fechas.getTamList(); i++) {
						
						resultado = new String (resultado + fechas.getNumPassUsuario(i) + "_" + fechas.getNombreUsuario(i) + "_"  + fechas.getTipoVisa() + "_" + fechas.getCodigo() + "\r\n");
					}
				}
			}
		}
		return resultado;
	}
	
	/**
	 * @return tipos de visa
	 * metodo que analiza todos el array de visas
	 */
	public String getTipoVisa() {
		String tipos = new String ("");
		List <String> desorden = new ArrayList<String>(); 
		for(Visa tipovisa : visa) {
			if(tipovisa!=null) {
				if(tipovisa instanceof Turismo)
					desorden.add("Turismo");
				if(tipovisa instanceof Trabajo)
					desorden.add("Trabajo");
				if(tipovisa instanceof Estudiante)
					desorden.add("Estudiante");
				if(tipovisa instanceof Conyuge)
					desorden.add("Conyuge");
			}
		}
		Collections.sort(desorden);
		for(String s : desorden) {
			tipos = tipos + s + "\r\n";
		}
		return tipos;
	}
	
	/**
	 * @param consVisa tipo de visa a consultar
	 * @return requisitos de la visa consultada
	 * Metodo que busca un tipo de visa y extrae los requisitos
	 */
/*	public String getRequisitosVisa(String consVisa) {
		String resultado = new String ("");
		Visa v = buscarVisa(consVisa);
			if(v!=null) {
				resultado = v.getRequisitos();
			}
		
		return resultado;
	}/*

	/**
	 * @param pass pasaporte 
	 * @return codigo solicitud de un usuario
	 * metodo que busca un usuario por pasaporte y extrae la cantidad de usuarios que tiene su solicitud
	 */
	public int getUsuariosSolicitudes(String pass) {
		Usuario user = buscarUsuario(pass);
		if(user == null) {
			return -1;
		}
		return user.getSolicitudes();
	}
	
	/**
	 * @param pass codigo de solicitud
	 * @return cantidad de usuarios para una solicitud
	 * Metodo que busca una solicitud con el codigo y retorna cuantos usuarios tienen la misma solicitud
	 */
	public int getUsuariosSolicitudes(int pass) {
		Solicitud sol = buscarSolicitud(pass);
		if(sol == null) {
			return -1;
		}
		return sol.getTamList();
	}
	
	/**
	 * @param pass pasaporte
	 * @return codigo de solicitud
	 * Metodo que busca un usuario por pasaporte y retorna codigo de solicitud
	 */
	public int getCodigoSolicitud(String pass) {
		Usuario user = buscarUsuario(pass);
		return user.getCodigo();
	}
	
	/**
	 * @param codigo codigo de solicitud
	 * @param i posicion del array 
	 * @return pasaporte del usuario numero "i" de la solicitud
	 * metodo que busca una solicitud y extrae el pasaporte del usuario "i"
	 */
	public String getPassSolicitud(int codigo, int i) {
		Solicitud sol = buscarSolicitud(codigo);
		return sol.getNumPassUsuario(i);
	}

	/**
	 * @param codigo codigo de solicitud
	 * @param i posicion del array 
	 * @return fecha de nacimiento del usuario numero "i" de la solicitud
	 * metodo que busca una solicitud y extrae la fecha de nacimiento del usuario "i"
	 */
	public LocalDate getFechaSolicitante(int codigo, int i) {
		Solicitud sol = buscarSolicitud(codigo);
		if(sol == null) {
			return null;
		}
		return sol.getFechaUsuario(i);
	}

	/**
	 * @param valorVisa costo de la visa para el usuario
	 * @return impuesto por la visa a comprar
	 * metodo que segun el porcentaje del impuesto saca el valor a pagar en impuesto
	 */
	public double getImpuesto(double valorVisa) {
		
		return ((impuesto/100)*valorVisa);
	}

	/**
	 * @param codigo codigo de solicitud
	 * @param i posicion en el array de usuarios solicitantes
	 * @return nombre del usuario "i"
	 * metodo que busca una solicitud con su codigo y extrae el nombre del usuario "i"
	 */
	public String getSolicitudNombre(int codigo, int i) {
		Solicitud sol = buscarSolicitud(codigo);
		return sol.getNombreUsuario(i);
	}

	/**
	 * @param codigo codigo solicitud
	 * @return tipo de visa
	 * metodo que busca una solicitud con su codigo y extrae el tipo de visa solicitada por su o sus usuarios
	 */
	public String getVisaSolicitante(int codigo) {
		Solicitud sol = buscarSolicitud(codigo);
		return sol.getTipoVisa();
	}
	
	/**
	 * @param pass pasaporte del usuario
	 * @return vetor con datos del usuario
	 * metodo que busca un usuario por su pasaporte y extrae todos sus atributos
	 */
	public String [] getUsuarioDatos(String pass) {
		String [] resultado = new String [6];
		Usuario user = buscarUsuario(pass);
		resultado [0] = user.getNumPasaporte();
		resultado [1] = user.getNombre();
		resultado [2] = user.getPaisNacimiento();
		resultado [3] = user.getCiudadNacimiento();
		resultado [4] = user.getFechaNacimiento().toString();
		resultado [5] = user.getEmail();
		return resultado;
	}
	
	/**
	 * @param pass codigo de solicitud
	 * @return datos del usuario solicitante principal
	 * metodo que busca una solicitud por el codigo y extrae los atributos del solicitante principal
	 */
	public String [] getUsuarioDatos(int pass) {
		String [] resultado = new String [6];
		Solicitud sol = buscarSolicitud(pass);
		resultado [0] = sol.getNumPassUsuario(0);
		resultado [1] = sol.getNombreUsuario(0);
		resultado [2] = sol.getPaisUsuario(0);
		resultado [3] = sol.getCiudadUsuario(0);
		resultado [4] = sol.getFechaUsuario(0).toString();
		resultado [5] = sol.getEmailUsuario(0);
		return resultado;
	}
	
	/**
	 * @return atributo moneda
	 * getter moneda de la embajada
	 */
	public String getMoneda() {
		return moneda;
	}
	
	/**
	 * @return atributo cambioOficial
	 * getter cambio de moneda
	 */
	public double getTasaCambio() {
		return cambioOficial;
	}
	
	/**
	 * @return atributo paisEmbajada
	 * getter nombre pais embajada
	 */
	public String getEmbajada() {
		return paisEmbajada;
	}
	
	/**
	 * @return booleano que especifica si hay usuarios 
	 */
	public boolean isEmpty() {
		return usuario.isEmpty();
	}
	
	/**
	 * @return lista con los datos de los usuarios
	 */
	public ArrayList<String[]> getUsuarios (){
		
		ArrayList<String[]> resultado = new ArrayList<String[]> ();
		Set<String> keys = usuario.keySet();
		for(String s:keys) {
			String [] usuarios = new String [7];
			usuarios[0] = (usuario.get(s)).getNumPasaporte();
			usuarios[1] = (usuario.get(s)).getNombre();
			usuarios[2] = (usuario.get(s)).getPaisNacimiento();
			usuarios[3] = (usuario.get(s)).getCiudadNacimiento();
			usuarios[4] = ((usuario.get(s)).getFechaNacimiento()).toString();
			usuarios[5] = (usuario.get(s)).getEmail();
			usuarios[6] = (usuario.get(s)).getInfo();
			resultado.add(usuarios);
		}
		return resultado;
	}

	public Map<String, Requisito> getRequisito() {
		return requisito;
	}

	public void setRequisito(Map<String, Requisito> requisito) {
		this.requisito = requisito;
	}

	public PaisEmbajada getPais() {
		return pais;
	}

	public void setPais(PaisEmbajada pais) {
		this.pais = pais;
	}


}
