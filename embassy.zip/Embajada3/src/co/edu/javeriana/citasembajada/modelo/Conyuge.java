package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;

public class Conyuge extends Visa implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param descripcion requisitos visa
	 * @param datos datos de la visa
	 * constructor de visas
	 */
	public Conyuge(String[] datos) {
		super(datos);
	}
}
