/**
 * 
 */
package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Visa implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected int id;
	protected double valor;
	protected List<Solicitud> solicitud = new ArrayList<Solicitud>();
	
	/**
	 * constructor por defecto
	 */
	public Visa() {
		solicitud = new ArrayList<Solicitud>();
	}
	/**
	 * @param descripcion vetor de string con requisitos de las visas
	 * @param datos vector de string con datos de las visas
	 * constructor que llena los datos y crea los requsitos
	 */
	public Visa(String[] datos) {
		id = Integer.parseInt(datos[0].replace(" ", ""));
		valor = (Double.parseDouble(datos[2]));
	}
	
	/**
	 * @param solicitudes objetos Solicitud
	 * a�ade una solicitud para ese tipo de visa
	 */
	public void agregarSolicitud(Solicitud solicitudes) {
		solicitud.add(solicitudes);
	}
	
	/**
	 * @return valor de la visa
	 * getter valor
	 */
	public double getValor() {
		return valor;
	}
	
	/**
	 * @return int id
	 * get id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id int id
	 * set id
	 */
	public void setId(int id) {
		this.id = id;
	}
}
