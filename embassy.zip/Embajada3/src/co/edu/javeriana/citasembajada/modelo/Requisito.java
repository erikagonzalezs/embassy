package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;

public class Requisito implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String descripcion;
	
	/**
	 * @param descripcion del requisito
	 * Constructor para guardar la descripcion
	 */
	public Requisito(String descripcion) {
		this.descripcion=descripcion;
	}
	
	/**
	 * @return retorna la descripcion
	 * getter del atributo descripcion
	 */
	public String getDescripcion(){
		return descripcion;
	}
}
