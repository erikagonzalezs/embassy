/**
 * 
 */
package co.edu.javeriana.citasembajada.modelo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import co.edu.javeriana.citasembajada.persistencia.ManejoArchivos;

public class ControladorCitasEmbajada {
	
	private ManejoArchivos archivos = new ManejoArchivos();
	
	private ISistemaCitasEmbajada sistemas = new SistemaCitasEmbajada();
	private SistemaCitasEmbajada s = (SistemaCitasEmbajada) sistemas;

	/**
	 * @param args main
	 * @throws IOException excepcion I/O
	 * El main coordina Util, InterfazConsola, SistmaCitasEmbajada y ManejoArchivos
	 */
	public String asignarEmbajada(String nompais, File file) {
		
		String []sistema = archivos.arch(nompais, file); 
		if(sistema==null) {
			return null;
		}
		sistemas = new SistemaCitasEmbajada(sistema);
		s = (SistemaCitasEmbajada) sistemas;
		return "Embajada cargado con exito-"+s.getEmbajada()+"-"+String.format("%.0f", s.getTasaCambio())+"-"+s.getMoneda();
	}
	
	/**
	 * @param file archivo con solicitantes
	 * @return mensaje de error/exito
	 */
	public String asignarSolicitantes(File file){
		
		List<String []> usuarios = new ArrayList<String []> (); 
		usuarios  = archivos.usuarios(file);
		if(usuarios == null) {
			return null;	
		}
		return s.setUsuario(usuarios);
	}
	
	/**
	 * @param file archivo con tarifas
	 * @return mensaje de error/exito
	 */
	public String asignarVisas(File file) {
		List<String []> cod = new ArrayList<String []> ();
		cod = archivos.cod(file);
		return s.setVisa(cod);
	}
	
	/**
	 * @return todos los usuarios
	 */
	public ArrayList<String[]> keys() {
		if(!s.isEmpty()) {
			return s.getUsuarios();
		}
		return null;
	}
	
	/**
	 * @param pass pasaporte
	 * @param e empresa
	 * @param i_c cargo
	 * @return mensaje de error/exito
	 */
	public String trabajo(String pass, String e, String i_c) {
		String resultado = sistemas.agregarSolicitud(pass, "Trabajo", 182, e, i_c);
		s = (SistemaCitasEmbajada) sistemas;
		return resultado;
	}
	
	/**
	 * @param dias dias de estadia
	 * @param otrosSol lista con solicitantes
	 * @param pass pasaporte principal
	 * @return mensaje de error/exito
	 */
	public String turismo(int dias, String [] otrosSol, String pass) {
		String resultado = sistemas.agregarSolicitud(pass, otrosSol, "Turismo", dias, null, null);
		s = (SistemaCitasEmbajada) sistemas;
		return resultado;
	}
	
	/**
	 * @param cod codigo de solicitud
	 * @param otrosSol lista con solicitantes
	 * @return mensaje de error/exito
	 */
	public String addTurismo(int cod, String [] otrosSol) {
		String resultado = sistemas.agregarSolicitud(otrosSol, cod);
		s = (SistemaCitasEmbajada) sistemas;
		return resultado;
	}
	
	/**
	 * @param np numero de pasaporte
	 * @return mensaje de error/exito
	 * 
	 */
	public String calcularValorVisa(String np) {
		if(s.getEmbajada() == null) 
			return "*No se ha cargado embajada*";
		
		return sistemas.calcularValorVisa(np);
	}
	
	/**
	 * @param cp numero de solicitud
	 * @return mensaje de error/exito
	 */
	public String calcularValorVisa(int cp) {
		if(s.getEmbajada() == null) 
			return "*No se ha cargado embajada*";
		
		return sistemas.calcularValorVisa(cp);
	}
	
	/**
	 * @param f fecha de las citas
	 * @return string con las citas separadas ppr "_"
	 * @throws IOException
	 */
	public String reportarCitas(String f) throws IOException {
		if(s.getEmbajada() == null) {
			return "*No se ha cargado embajada";
		}
		
		LocalDate fecha = Utils.stringToLocalDate(f);
		if(fecha==null) {
			return "*Fecha invalida";
		}
		String resultado = s.getSolicitud(fecha);
		archivos.reportarCitasFecha(f, resultado, s.getEmbajada());
		return resultado;
	}
	
	/**
	 * @return string con los beneficiarios separados por "_"
	 */
	public String listarBeneficiarios() {
		String resultado = new String("");
		
		if(s.getEmbajada() == null) {
			return "*No se ha cargado embajada";
		}
		ArrayList <String> lista = sistemas.listarBeneficiados();
		
		archivos.reportarListaBeneficiados(lista);
		
		for(int i=1;i<(lista.size())-1;i++) {
			resultado = resultado + lista.get(i);
		}
		return resultado;
	}
	
	/**
	 * @param ruta ruta a donde sera enviado
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public void guardarEmbajada(String ruta) throws FileNotFoundException, IOException {
		s = (SistemaCitasEmbajada) sistemas;
		archivos.guardarEmbajada(s, ruta);
	}
	
	/**
	 * @param file archivo para cargar
	 * @throws FileNotFoundException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	public void cargarEmbajada(File file) throws FileNotFoundException, ClassNotFoundException, IOException {
		sistemas = archivos.cargarBanco(file);
		s = (SistemaCitasEmbajada) sistemas;
	}

}
