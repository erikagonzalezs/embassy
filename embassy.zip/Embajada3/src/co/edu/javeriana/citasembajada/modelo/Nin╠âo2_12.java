package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;

public class Niño2_12 extends Usuario implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String escolaridad;
	private Escolaridad nivel;
	
	/**
	 * @param solicitante vetor de string con informacion de el usuario
	 * constructor con la informacion del usuario
	 */
	public Niño2_12(String[] solicitante) {
		super(solicitante);
		setEscolaridad(solicitante[6]);
	}

	/* (non-Javadoc)
	 * @see co.edu.javeriana.citasembajada.modelo.Usuario#calcularValorVisa()
	 * calculador de visa
	 */
	@Override
	public double calcularValorVisa() {
		return 0;
	}

	/**
	 * @return string escolaridad
	 * get de escolaridad
	 */
	public String getInfo() {
		return escolaridad;
	}

	/**
	 * @param escolaridad string escolaridad
	 * set de escolaridad
	 */
	public void setEscolaridad(String escolaridad) {
		this.escolaridad = escolaridad;
	}

	/**
	 * @return enumerado escolaridad
	 */
	public Escolaridad getNivel() {
		return nivel;
	}

	/**
	 * @param nivel nivel de escolaridad
	 */
	public void setNivel(Escolaridad nivel) {
		this.nivel = nivel;
	}

}
