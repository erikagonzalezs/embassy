package co.edu.javeriana.citasembajada.modelo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Utils {

	/**
	 * @param fecha cadena 
	 * @return localdate
	 * metodo que convierte una cadena string en localdate
	 */
	public static LocalDate stringToLocalDate(String fecha) {
		try {
		LocalDate resultado = null;
		String [] partfecha = fecha.split("\\-");
		if((partfecha[0].length()==4) && (partfecha[1].length()==2) && (partfecha[2].length()==2)) {
			String yyyyMMdd = new String (partfecha[0]+"-"+partfecha[1]+"-"+partfecha[2]);
			DateTimeFormatter dtf =DateTimeFormatter.ofPattern("yyyy-MM-dd");
			resultado = LocalDate.parse(yyyyMMdd,dtf);
		}
		if((partfecha[0].length()==2) && (partfecha[1].length()==2) && (partfecha[2].length()==4)) {
			String yyyyMMdd = new String (partfecha[2]+"-"+partfecha[1]+"-"+partfecha[0]);
			DateTimeFormatter dtf =DateTimeFormatter.ofPattern("yyyy-MM-dd");
			resultado = LocalDate.parse(yyyyMMdd,dtf);
		}
		return resultado;
		}
		catch(Exception e){
			System.out.println("Error: " + e);
		}
		return null;
	}

	/**
	 * @param fecha localdate
	 * @return entero
	 * metodo que obtiene la edad de un usuario a partir un local date
	 */
	public static int getEdad(LocalDate fecha) {
		LocalDate hoy = LocalDate.now();
		return hoy.getYear()-fecha.getYear();
	}
	
}
