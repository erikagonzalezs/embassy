/**
 * 
 */
package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Solicitud implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int codigo;
	private int diasEstadia;
	private static int CONSECUTIVO=555111;
	private String estado;
	private LocalDate fecha;
	private List<Usuario> usuario;
	private Visa visa;
	private String empresa;
	private String cargo;
	private String escolaridad;
	private String institucion;
	
	/**
	 * cosntructor por defecto
	 */
	public Solicitud() {
		usuario = new ArrayList<Usuario> ();
		codigo = CONSECUTIVO;
		estado = new String ("Proceso");
		CONSECUTIVO+=110011;
	}
	
	/**
	 * @param user objeto tipo Usuario
	 * metodo que a�ade un usuario al array de usuarios
	 */
	public void agregarUsuarioSolicitud(Usuario user) {
		usuario.add(user);
	}
	
	/**
	 * @return atributo codigo
	 * metodo que obtiene el codigo de la solicitud
	 */
	public int getCodigo() {
		return codigo;
	}
	
	/**
	 * @return atributo fehca
	 * metodo que obtiene la fecha de solicitud
	 */
	public LocalDate getFecha() {
		return fecha;
	}
	
	/**
	 * @return tama�o lista de usuarios
	 * metodo que obtiene el tama�o de la lista de usuarios
	 */
	public int getTamList() {
		return usuario.size();
	}
	
	/**
	 * @param i posicion en le array de usuarios
	 * @return pasaporte para el usuario "i"
	 * metodo que obtiene el pasaporte del usuario "i"
	 */
	public String getNumPassUsuario(int i) {
		return usuario.get(i).getNumPasaporte();
	}
	
	/**
	 * @param i posicion en le array de usuarios
	 * @return nombreusuario para el usuario "i"
	 * metodo que obtiene el nombre del usuario "i"
	 */
	public String getNombreUsuario(int i) {
		return usuario.get(i).getNombre();
	}
	
	/**
	 * @param i posicion en le array de usuarios
	 * @return pais del usuario "i"
	 * metodo que obtiene el pais del usuario "i"
	 */
	public String getPaisUsuario(int i) {
		return usuario.get(i).getPaisNacimiento();
	}
	
	/**
	 * @param i posicion en le array de usuarios
	 * @return ciudad del usuario "i"
	 * metodo que obtiene la ciudad del usuario "i"
	 */
	public String getCiudadUsuario(int i) {
		return usuario.get(i).getCiudadNacimiento();
	}
	
	/**
	 * @param i posicion en le array de usuarios
	 * @return fecha nacimiento para el usuario "i"
	 * metodo que obtiene la fecha de naciemiento del usuario "i"
	 */
	public LocalDate getFechaUsuario(int i) {
		return usuario.get(i).getFechaNacimiento();
	}
	
	/**
	 * @param i posicion en le array de usuarios
	 * @return email para el usuario "i"
	 * metodo que obtiene el email del usuario "i"
	 */
	public String getEmailUsuario(int i) {
		return usuario.get(i).getEmail();
	}
	
	
	/**
	 * @return tipo de visa 
	 * metodo que obtiene  el tipo de visa solicitada
	 */
	public String getTipoVisa() {
		if(visa instanceof Turismo) {
			return "Turismo";
		}
		if(visa instanceof Trabajo) {
			return "Trabajo";
		}
		if(visa instanceof Estudiante) {
			return "Estudiante";
		}
		if(visa instanceof Conyuge) {
			return "Conyuge";
		}
		return null;
	}
	
	/**
	 * @return estado
	 * metodo que obtiene el estado de la solicitud
	 */
	public String getEstado() {
		return estado;
	}
	
	/**
	 * @param visa objeto visa
	 * setter atributo visa
	 */
	public void setVisa(Visa visa) {
		this.visa=visa;
	}

	/**
	 * @param fecha disponible pasa solicitud
	 * setter atributo fecha
	 */
	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	/**
	 * @return int dias estadia
	 * get dias estadia
	 */
	public int getDiasEstadia() {
		return diasEstadia;
	}

	/**
	 * @param diasEstadia int dias estadia
	 * set dias estadia
	 */
	public void setDiasEstadia(int diasEstadia) {
		this.diasEstadia = diasEstadia;
	}

	/**
	 * @return string empresa
	 * get empresa
	 */
	public String getEmpresa() {
		return empresa;
	}

	/**
	 * @param empresa string empresa
	 * set empresa
	 */
	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	/**
	 * @return string cargo
	 * get cargo
	 */
	public String getCargo() {
		return cargo;
	}

	/**
	 * @param cargo string cargo
	 * set cargo
	 */
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	/**
	 * @return string escolaridad
	 * get escolaridad
	 */
	public String getEscolaridad() {
		return escolaridad;
	}

	/**
	 * @param escolaridad string escolaridad
	 * set escolaridad
	 */
	public void setEscolaridad(String escolaridad) {
		this.escolaridad = escolaridad;
	}

	/**
	 * @return string institucion
	 * get institucion
	 */
	public String getInstitucion() {
		return institucion;
	}

	/**
	 * @param institucion string institucion
	 * set institucion
	 */
	public void setInstitucion(String institucion) {
		this.institucion = institucion;
	}
	/**
	 * @param i int i
	 * @return objeto usuario
	 * get para un usuario en la posicion del array "i"
	 */
	public Usuario getUsuario(int i){
		return usuario.get(i);
	}

	
}
