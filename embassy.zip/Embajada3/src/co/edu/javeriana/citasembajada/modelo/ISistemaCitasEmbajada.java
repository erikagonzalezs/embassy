package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;
import java.util.ArrayList;

public interface ISistemaCitasEmbajada extends Serializable{
	
	/**
	 * @param pass pasaporte
	 * @param otrosSolicitantes lista con acompa�antes
	 * @param tvisa tipo de visa solicitada
	 * @param dias dias de estadia
	 * @param e escolaridad o empresa
	 * @param i_c institucio o compa�ia
	 * @return Resultado del proceso
	 * metodo que agrega una solicitud
	 */
	public String agregarSolicitud(String pass,String [] otrosSolicitantes, String tvisa, int dias, String e, String i_c);
	/**
	 * @param pass pasaporte
	 * @param tvisa tipo de visa solicitada
	 * @param dias dias de estadia
	 * @param e escolaridad o empresa
	 * @param i_c institucio o compa�ia
	 * @return Resultado del proceso
	 * metodo que agrega una solicitud
	 */
	public String agregarSolicitud(String pass, String tvisa, int dias, String e, String i_c);
	
	/**
	 * @param otrosSolicitantes lista con los solicitantes
	 * @param pass pasaporte
	 * @return mensaje de error/exito
	 */
	public String agregarSolicitud(String [] otrosSolicitantes,int pass);
	/**
	 * @param cod codigo de reserva
	 * @param descuento cantidad de descuento
	 * @return valor de la visa
	 * metodo que calcula el valor de la visa
	 */
	public double calcularValorVisa(int cod, double descuento);
	/**
	 * @param pass pasasporte
	 * @return resultado con valor de visa y solicitantes
	 * metodo que coordina el calculo del valor de la visa a partir del pasaporte
	 */
	public String calcularValorVisa(String pass);
	/**
	 * @param codigo codigo de reserva
	 * @return resultado con valor de visa y solicitantes
	 * metodo que coordina el calculo del valor de la visa a partir del codigo de reserva
	 */
	public String calcularValorVisa(int codigo);
	/**
	 * @return lista de beneficiados
	 * metodo que calcula el valor que habrian pagado los beneficiados sin descuento
	 */
	public ArrayList<String> listarBeneficiados();
}
