package co.edu.javeriana.citasembajada.modelo;

import java.io.Serializable;

public class AdultoMayor extends Usuario implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param solicitante vetor de string con informacion de el usuario
	 * constructor con la informacion del usuario
	 */
	public AdultoMayor(String[] solicitante) {
		super(solicitante);
	}

	/* (non-Javadoc)
	 * @see co.edu.javeriana.citasembajada.modelo.Usuario#calcularValorVisa()
	 * calculador de visas
	 */
	@Override
	public double calcularValorVisa() {
		return 0;
	}
	
	/* (non-Javadoc)
	 * @see co.edu.javeriana.citasembajada.modelo.Usuario#getInfo()
	 * Obtiene informacion adicional
	 */
	public String getInfo() {
		return "";
	}
}
